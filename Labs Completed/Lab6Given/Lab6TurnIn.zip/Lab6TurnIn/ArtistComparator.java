import java.util.Comparator;

public class ArtistComparator implements Comparator<Song> {
    public int compare(Song s1, Song s2){
        return ((String)s1.getArtist()).compareTo((String)s2.getArtist());
    }
}
