public enum ActionKind {
    ACTIVITY, ANIMATION
}
