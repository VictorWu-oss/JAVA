public class AbstractEntity {
}
