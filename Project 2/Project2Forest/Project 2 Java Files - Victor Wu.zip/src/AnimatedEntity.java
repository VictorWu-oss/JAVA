public interface AnimatedEntity{
    double getAnimationPeriod();
}
