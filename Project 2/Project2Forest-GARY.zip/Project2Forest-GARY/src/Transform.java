public interface Transform {
    boolean transform(WorldModel world, EventScheduler scheduler, ImageStore imageStore);
}