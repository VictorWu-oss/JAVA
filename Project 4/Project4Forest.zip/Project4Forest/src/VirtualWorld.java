import java.awt.*;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.*;
import java.util.List;

import processing.core.*;

import javax.sound.sampled.Port;

public final class VirtualWorld extends PApplet {
    private static String[] ARGS;

    public static final int VIEW_WIDTH = 640;
    public static final int VIEW_HEIGHT = 480;
    public static final int TILE_WIDTH = 32;
    public static final int TILE_HEIGHT = 32;

    public static final int VIEW_COLS = VIEW_WIDTH / TILE_WIDTH;
    public static final int VIEW_ROWS = VIEW_HEIGHT / TILE_HEIGHT;

    public static final String IMAGE_LIST_FILE_NAME = "imagelist";
    public static final String DEFAULT_IMAGE_NAME = "background_default";
    public static final int DEFAULT_IMAGE_COLOR = 0x808080;

    private String loadFile = "world.sav";
    private long startTimeMillis = 0;

    private ImageStore imageStore;
    private WorldModel world;
    private WorldView view;
    private EventScheduler scheduler;



    public void settings() {
        size(VIEW_WIDTH, VIEW_HEIGHT);
    }

    /*
       Processing entry point for "sketch" setup.
    */
    public void setup() {
        parseCommandLine(ARGS);
        loadImages(IMAGE_LIST_FILE_NAME);
        loadWorld(loadFile, this.imageStore);

        this.view = new WorldView(VIEW_ROWS, VIEW_COLS, this, world, TILE_WIDTH, TILE_HEIGHT);
        this.scheduler = new EventScheduler();
        this.startTimeMillis = System.currentTimeMillis();
        this.scheduleActions(this.world, this.scheduler, this.imageStore);
    }

    public void draw() {
        double appTime = (System.currentTimeMillis() - this.startTimeMillis) * 0.001;
        double frameTime = (appTime - this.scheduler.getCurrentTime());
        this.update(frameTime);
        this.view.drawViewport();
    }

    public void update(double frameTime){
        this.scheduler.updateOnTime(frameTime);
    }

    // Just for debugging and for P5
    // Be sure to refactor this method as appropriate
    @Override
    public void mousePressed() {
        Point pressed = mouseToPoint();
        System.out.println("CLICK! " + pressed.x + ", " + pressed.y);

        addSoldier(world, scheduler, imageStore, pressed);
        addPortal(world, scheduler, imageStore, pressed);

        // Draw 5x5 black square
        for (int dy = -1; dy <= 1; dy++) {
            for (int dx = -1; dx <= 1; dx++) {
                Point bgPt = new Point(pressed.x + dx, pressed.y + dy);
                if (world.withinBounds(bgPt)) {
                    world.setBackgroundCell(bgPt, new Background("darkmatter", imageStore.getImageList("darkmatter")));
                }
            }
        }

        // Transform all Dudes in a 5x5 grid into DudeSuper
        for (int dy = -2; dy <= 2; dy++) {
            for (int dx = -2; dx <= 2; dx++) {
                Point checkPt = new Point(pressed.x + dx, pressed.y + dy);
                if (world.withinBounds(checkPt) && world.isOccupied(checkPt)) {
                    Entity entity = world.getOccupant(checkPt).get();
                    if (entity instanceof DudeNotFull || entity instanceof DudeFull) {
                        world.removeEntity(scheduler, entity);
                        scheduler.unscheduleAllEvents(entity);
                        addSuperDude(world, scheduler, imageStore, checkPt);
                        System.out.println("Mouse-click: Replaced " + entity.getId() + " with DudeSuper at " + checkPt);
                    }
                }
            }
        }
    }

    public void addSoldier(WorldModel world, EventScheduler scheduler, ImageStore imageStore, Point pt){
        Soldier soldier = Soldier.createSoldier(Soldier.SOLDIER_KEY, pt, 0.9, 0.05, imageStore.getImageList("soldier"));
        world.addEntity(soldier);
        soldier.scheduleActions(scheduler, world, imageStore);
    }

    public void addPortal(WorldModel world, EventScheduler scheduler, ImageStore imageStore, Point pt){
        Portal portal = Portal.createPortal(Portal.PORTAL_KEY, pt, 0.06, imageStore.getImageList("portal"));
        world.addEntity(portal);
        portal.scheduleActions(scheduler, world, imageStore);
    }

    public void addSuperDude(WorldModel world, EventScheduler scheduler, ImageStore imageStore, Point pt){
        DudeSuper dudeSuper = DudeSuper.createDudeSuper(DudeSuper.SUPERDUDE_KEY, pt, 0.55,0.05, 99, imageStore.getImageList("superdude"));
        world.addEntity(dudeSuper);
        dudeSuper.scheduleActions(scheduler, world, imageStore);
    }

    public void scheduleActions(WorldModel world, EventScheduler scheduler, ImageStore imageStore) {
        for (Entity entity : world.getEntities()) {
            if (entity instanceof ActiveAnimatedEntity active) {
                active.scheduleActions(scheduler, world, imageStore);
            } else if (entity instanceof Obstacle obstacle) {
                obstacle.scheduleActions(scheduler, world, imageStore);
            }
        }
    }


    private Point mouseToPoint() {
        return view.getViewport().viewportToWorld(mouseX / TILE_WIDTH, mouseY / TILE_HEIGHT);

    }

    public void keyPressed() {
        if (key == CODED) {
            int dx = 0;
            int dy = 0;

            switch (keyCode) {
                case UP -> dy -= 1;
                case DOWN -> dy += 1;
                case LEFT -> dx -= 1;
                case RIGHT -> dx += 1;
            }
            view.shiftView(dx, dy);
        }
    }

    public static Background createDefaultBackground(ImageStore imageStore) {
        return new Background(DEFAULT_IMAGE_NAME, imageStore.getImageList(DEFAULT_IMAGE_NAME));
    }

    public static PImage createImageColored(int width, int height, int color) {
        PImage img = new PImage(width, height, RGB);
        img.loadPixels();
        Arrays.fill(img.pixels, color);
        img.updatePixels();
        return img;
    }

    public void loadImages(String filename) {
        this.imageStore = new ImageStore(createImageColored(TILE_WIDTH, TILE_HEIGHT, DEFAULT_IMAGE_COLOR));
        try {
            Scanner in = new Scanner(new File(filename));
            WorldModel.loadImages(in, imageStore,this);
        } catch (FileNotFoundException e) {
            System.err.println(e.getMessage());
        }
    }

    public void loadWorld(String file, ImageStore imageStore) {
        this.world = new WorldModel();
        try {
            Scanner in = new Scanner(new File(file));
            world.load(in, imageStore, createDefaultBackground(imageStore));
        } catch (FileNotFoundException e) {
            Scanner in = new Scanner(file);
            world.load(in, imageStore, createDefaultBackground(imageStore));
        }
    }

    public void parseCommandLine(String[] args) {
        if (args.length != 0) {
            this.loadFile = args[0]; // Instead of the default world.sav
        }
    }

    public static void main(String[] args) {
        VirtualWorld.ARGS = args;
        PApplet.main(VirtualWorld.class);
    }

    public static List<String> headlessMain(String[] args, double lifetime){
        VirtualWorld.ARGS = args;

        VirtualWorld virtualWorld = new VirtualWorld();
        virtualWorld.setup();
        virtualWorld.update(lifetime);

        return virtualWorld.world.log();
    }
}
