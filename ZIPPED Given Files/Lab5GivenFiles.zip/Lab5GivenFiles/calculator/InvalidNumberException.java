class InvalidNumberException
   extends ScannerException
{
}
